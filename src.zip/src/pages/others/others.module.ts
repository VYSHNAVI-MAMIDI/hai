import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OthersPage } from './others';

@NgModule({
  declarations: [
    OthersPage,
  ],
  imports: [
    IonicPageModule.forChild(OthersPage),
  ],
})
export class OthersPageModule {}
